WI using 2020 census VTD shapes... note these are SLIGHTLY DIFFERENT from the 2020 WI 'ward' shapes available from the State of Wisconsin (legislative data department). WI maintains their 'wards' are more accurate but Daves' redistricting uses census shapes and want to avoid discrepancies resulting in district assignments not read in propertly.


This file contains election data (as per https://github.com/mggg-states/WI-shapefiles)
and 2019 population data from american community survey, as per  https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/T9VMJO
using the acs19block20pop.zip files for WI (code=55)

The 'TOTPOP' field is a copy of POP19 (not the old 2010 population data).
GEOID10 is a copy of GEOID20, NOT the original GEOID10 geotag... for compatibility with routines searching for GEOID10
The GEOID20/ GEOID10 tags are ported from the 2020 WI wards looking for the census VTD that *most closely* matches a WI Ward.