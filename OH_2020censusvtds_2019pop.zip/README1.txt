OH VTD data using 2020 census shapes and 2019 American Community Survey population estimates 
Source for the 2019 population estimates per block, which we aggregated into precinct totals are here: https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/T9VMJO
using the acs19block20pop.zip files for OH

Includes 2016 data (source MGGG https://github.com/mggg-states/OH-shapefiles)
2018 & 2020 data (source https://dataverse.harvard.edu/dataverse/electionscience)

Geotag - GEOID10 is copy of GEOID20

2016 (Pres, Sen)
2018 (Gov, ATG, Aud, SOS, Treas)
2020  (Pres)
election data